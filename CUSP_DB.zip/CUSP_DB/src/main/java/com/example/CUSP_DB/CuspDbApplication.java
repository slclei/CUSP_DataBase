package com.example.CUSP_DB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CuspDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(CuspDbApplication.class, args);
	}

}
